package com.codename1.googlemaps;

public class InternalNativeMapsImpl {
    public void initialize() {
    }

    public int getMaxZoom() {
        return 0;
    }

    public long finishPath(long param) {
        return 0;
    }

    public void calcLatLongPosition(int param, int param1) {
    }

    public double getScreenLon() {
        return 0;
    }

    public double getScreenLat() {
        return 0;
    }

    public int getScreenY() {
        return 0;
    }

    public void removeMapElement(long param) {
    }

    public double getLatitude() {
        return 0;
    }

    public int getScreenX() {
        return 0;
    }

    public void setRotateGestureEnabled(boolean param) {
    }

    public void removeAllMarkers() {
    }

    public void calcScreenPosition(double param, double param1) {
    }

    public net.rim.device.api.ui.Field createNativeMap(int param) {
        return null;
    }

    public double getLongitude() {
        return 0;
    }

    public long beginPath() {
        return 0;
    }

    public void setPosition(double param, double param1) {
    }

    public float getZoom() {
        return 0;
    }

    public void setZoom(double param, double param1, float param2) {
    }

    public void deinitialize() {
    }

    public int getMapType() {
        return 0;
    }

    public int getMinZoom() {
        return 0;
    }

    public void addToPath(long param, double param1, double param2) {
    }

    public void setMapType(int param) {
    }

    public void setShowMyLocation(boolean param) {
    }

    public long addMarker(byte[] param, double param1, double param2, String param3, String param4, boolean param5) {
        return 0;
    }

    public boolean isSupported() {
        return false;
    }

}
